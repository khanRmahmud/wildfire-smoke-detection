# Smoke Detection > 2023-09-18 4:03pm
https://universe.roboflow.com/louisiana-tech-university-ruston-louisiana-usa/smoke-detection-xm8uz

Provided by a Roboflow user
License: CC BY 4.0

