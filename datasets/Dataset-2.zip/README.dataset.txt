# smoke-detection-test-dataset > 2023-10-28 10:59am
https://universe.roboflow.com/louisiana-tech-university-ruston-louisiana-usa/smoke-detection-test-dataset

Provided by a Roboflow user
License: CC BY 4.0

